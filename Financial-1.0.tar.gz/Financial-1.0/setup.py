from distutils.core import setup

setup(name='Financial',
      version='1.0',
      py_modules=['Launcher','GUI','LoadAPI']
      )
